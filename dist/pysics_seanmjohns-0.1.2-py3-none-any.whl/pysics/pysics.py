#There currently are no global configuration variables
